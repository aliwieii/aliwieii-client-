#version 120

attribute vec4 Position;
attribute vec2 TexCoord;

varying vec2 texCoord;
varying vec2 oneTexel;

uniform vec2 InSize;

void main() {
    gl_Position = Position;
    texCoord = TexCoord;
    oneTexel = 1.0 / InSize;
}
